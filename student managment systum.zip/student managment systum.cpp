#include<iostream>
#include<iomanip>
#include<windows.h>
#include<fstream>
#include<string>
#include<string.h>
#include<conio.h>
using namespace std;
class student
{
	public://data menber
	    static int sid_count;
		int sid;
		string name,address,sme,dept;
	    long double contact;
	    
		student()//constructor
		{
		
			sid=sid_count;
			name='\0';
		
			contact=0;
			address='\0';
			sme='\0';
			dept='\0';
    	 }		 
    	 //methor or function
	void Admin_menu();
	void insertRecord();
	void showRecord();
	void searchRecord();
	void modifyRecord();
	void deleteRecord();
}e;
class administrator:public student
{
  public:
  void login();
  void main_menu();
  void child_menu();
  void attendence();
  	
}obj;
void administrator::login()
{
	p:
	system("cls");
	char ch;
	string password, username;
    cout<<"\n\n\n\n\n";
    cout<<"\t\t\t\t=====================================\n\n";
    cout<<"\t\t\t\t\t*****LOGIN PROCESS*****\n\n";
    cout<<"\t\t\t\t=====================================\n\n";
	
		cout<<"\tEnter a username :\t";
		cin.ignore();
	    getline(cin,username);
	    cout<<"\n\tEnter a password  : \t";
	    for(int i=0;i<5;i++)
	    {
	    ch=getch();
	    password+=ch;
	    cout<<"*";
		}
	    if(username=="zain" && password=="zaini")
	    {
	    	cout<<"\n\n\tCongratulation Login successfully......\n";
	    	cout<<"\n\n\t\tLoading";
	    	for(int i=0;i<3;i++)
	    	{
	    		Sleep(1000);
	    		cout<<".";
			}
	    student::Admin_menu();
		}
		else if(username != "zain" &&  password == "zaini")
		{
			cout<<"\n\n\tYou enter a wrong name....!!!!\a\n";
			getch();
			goto p;
		}
		else if(username == "zain"  && password != "zaini")
		{
cout<<"\n\n\tYou Enter a wrong password.....!!!!!\a\n";
			getch();
			goto p;
		}
	    else 
	    cout<<"\n\n\nUSERS NAME and PASSWORD both are worng....!!!!\a";
}
void administrator::main_menu()
{
	p:
	int choice;
	system("cls");
		cout<<"\t\t\t\t=====================================\n\n";
		cout<<"\t\t\t\t **********Control Panel**********\n\n";
		cout<<"\t\t\t\t=====================================\n\n";
	    cout<<"\n\n1=>Press 1 for admin \n";
	    cout<<"\n2=>Press 2 for student \n";
	    cout<<"\n3=>Press 3 for Exit \n\n";
	    cout<<"Enter your choice :";
	    cin>>choice;
	    switch(choice)
	    {
	    	case 1:
	    		login();
	    		break;
	    	case 2:
	    		child_menu();
	    		break;
	    	case 3:
	    		exit(0);
	    	default:
	    	cout<<"\n\nInvalid choice...\nPlease try again.....\n";
		}
		getch();
		goto p;
}
void administrator::child_menu()
{
	p:
	int choice;
  	system("cls");
		cout<<"\t\t\t\t=====================================\n\n";
		cout<<"\t\t\t\t **********Control Panel**********\n\n";
		cout<<"\t\t\t\t=====================================\n\n";
	    cout<<"\n\n1=>Press 1 for attendence \n";
	    cout<<"\n2=>Press 2 for check Detail \n";
	    cout<<"\n3=>Press 3 for Go back \n\n";
	    cout<<"Enter your choice :";
	    cin>>choice;
	    switch(choice)
	    {
	    	case 1:
	    		attendence();
	    		break;
	    	case 2:
	    		student::searchRecord();
	    		break;
	    	case 3:
	        	obj.main_menu();
	    	default:
	    	cout<<"\n\nInvalid choice...\nPlease try again.....\n";
		}
		getch();
		goto p;
}
void administrator::attendence()
{
    system("cls");
    	cout<<"\t\t\t\t=====================================\n\n";
		cout<<"\t\t\t\t ********Student Attendence**********\n\n";
		cout<<"\t\t\t\t=====================================\n\n";
		fstream file;
		SYSTEMTIME x;
		int test_id,a_date,a_month,a_year,t_id,count=0,found=0;
		file.open("student Record.txt",ios::in);
		if(!file)
		{
			cout<<"\n\n File openning error....!!\a\n";
		}
		else
		{
			cout<<"\n\n student ID : ";
			cin>>test_id;
	    	file>>name>>sid>>address>>contact>>sme>>dept;
		while(!file.eof())
		{
			if(test_id==sid)
			found++;
			file>>name>>sid>>address>>contact>>sme>>dept;
		}
		file.close();
		if(found>0)
		{
			GetSystemTime(&x);
			file.open("attendence.txt",ios::in);
			if(!file)
			{
				file.open("attendence.txt",ios::app | ios::out);
				file<<"  "<<test_id<<"  "<<x.wDay<<"  "<<x.wMonth<<"  "<<x.wYear<<endl;
				file.close();
				cout<<"\n\nYour Attendence Added Successfully.......";
			}
			else
			{
				file>>t_id>>a_date>>a_month>>a_year;
				while(!file.eof())
				{
				   if(test_id==t_id && a_date==x.wDay && a_month==x.wMonth && a_year==x.wYear)
				   {
				   	cout<<"\n\nYour  Attendence already added....\n";
				   	count++;
				   }	
					file>>t_id>>a_date>>a_month>>a_year;	
				}
				file.close();
				if(count==0)
				{
				file.open("attendence.txt",ios::app | ios::out);
				file<<"  "<<test_id<<"  "<<x.wDay<<"  "<<x.wMonth<<"  "<<x.wYear<<endl;
				file.close();
				cout<<"\n\nYour Attendence Added Successfully.......";
				}
			}
		}
		else
		cout<<"\n\nInvalid student ID....\n\a";
	}
		
}
void student::Admin_menu()
	{
	r:
	int choice;
	system("cls");
	cout<<"\n\n\t\t\t=================================================================";
	cout<<" student MANAGEMENT SYSTEM ";
	cout<<"\n\n\t\t\t=================================================================\n\n";
	cout<<"\t\t\t\t    ************Admin Control Panel**************\n\n";
	cout<<"\n 1=> Press 1 to Enter Record. "<<endl;
	cout<<"\n 2=> Press 2 to Show Record. "<<endl;
	cout<<"\n 3=> Press 3 to Delete Record. "<<endl;
	cout<<"\n 4=> Press 4 to Search  Record. "<<endl;
	cout<<"\n 5=> Press 5 to Modify Record. "<<endl;
	cout<<"\n 8=> Press 8 to Go back.  "<<endl;
	cout<<" \n%%%%%% Please Enter a choice  %%%%%%%: ";
	cin>>choice;
	switch(choice)
	{
			case 1:
				{
					system("cls");
					int n;
					cout<<"\n\n\tHow many student data do you want to enter : ";
					cin>>n;
					for(int i=0;i<n;i++)
					{
					  e.insertRecord();	
					}
				}
				break;
			case 2:
				showRecord();
				break;
			case 3:
				deleteRecord();
				break;
			case 4:
				searchRecord();
				break;
			case 5:
				modifyRecord();
				break;
		

			case 8:
			obj.main_menu();
			default :
			cout<<"\n!!!!!!!!!!!!!!!!!!!!!!!!!\nInvalid choice . Please try again....";
	}
	getch();
	goto r;
	}
void student::insertRecord()
	{
		system("cls");
		fstream file,file1;
		cout<<"\t\t\t\t=====================================\n\n";
		cout<<"\t\t\t\t **********Insert Record**********\n\n";
		cout<<"\t\t\t\t=====================================\n\n";
		cout<<"Enter a Name : ";
		cin.ignore();
		getline(cin,name);
		sid_count++;
	    sid=sid_count;
	
		cout<<"\n\tEnter a Address : ";
		cin.ignore();
		getline(cin,address);
		cout<<"\nEnter a Contact Number : ";
		cin>>contact;
	
		cout<<"\nEnter a  student smester : ";
		cin.ignore();
		getline(cin,sme);
		cout<<"\n\tEnter a department name : ";
		cin.ignore();
		getline(cin,dept);
		file.open("student Record.txt",ios::out|ios::app);
		file<<"  "<<name<<"  "<<sid<<"  "<<"  "<<address<<"  "<<contact<<"  "<<"  "<<sme<<"  "<<dept<<endl;
		file.close();
		cout<<"\n\n\n\t\t New Record is Inserted Successfully......\n";
	}
void student::showRecord()
	{
		system("cls");
		fstream file;
		cout<<"\t\t\t\t=====================================\n\n";
		cout<<"\t\t\t\t   *********Show Record**********\n\n";
		cout<<"\t\t\t\t=====================================\n\n";
		file.open("student Record.txt",ios::in);
		if(!file)
		{
			cout<<"\n\nFile Opening Error........\a\n";
			getch();
			Admin_menu();
		}
		file>>name>>sid>>address>>contact>>sme>>dept;
		cout<<"stu_Name"<<setw(10)<<"stu_ID"<<setw(10)<<"Address"<<setw(10)<<"  Contact Number"<<setw(15)<<"student sme"<<setw(15)<<"  Department Name"<<endl;
		while(!file.eof())
		{
	cout<<name<<setw(10)<<sid<<setw(10)<<setw(10)<<address<<setw(10)<<contact<<setw(15)<<sme<<setw(15)<<dept<<endl;

		file>>name>>sid>>address>>contact>>sme>>dept;
	   }
	   file.close();
	}
void student::searchRecord()
	{
		system("cls");
		fstream file;
		int stu_id,found=0;
		cout<<"\t\t\t\t=====================================\n\n";
		cout<<"\t\t\t\t   ********Search Record*********** \n";
		cout<<"\t\t\t\t=====================================\n\n";
		file.open("student Record.txt",ios::in);
		if(!file)
		{
			cout<<"\n\nFile Opening Error....\n\a";
		}
		else
		cout<<"\n\n Enter a student ID do you want to search :";
		cin>>stu_id;
		file>>name>>sid>>address>>contact>>sme>>dept;
		cout<<"stu_Name"<<setw(10)<<"stu_ID"<<setw(10)<<"Address"<<setw(10)<<"  Contact Number"<<setw(15)<<"student sme"<<setw(15)<<"  Department Name"<<endl;
		while(!file.eof())
		{
			if(stu_id == sid)
			{
				system("CLS");
				cout<<"\t\t\t\t=====================================\n\n";
				cout<<"\t\t\t\t   *******Search Record*******\n\n";
				cout<<"\t\t\t\t=====================================\n\n";
				cout<<name<<setw(10)<<sid<<setw(10)<<address<<setw(10)<<contact<<setw(15)<<sme<<setw(15)<<dept<<endl;

				found++;
			}
			file>>name>>sid>>address>>contact>>sme>>dept;
		}
		file.close();
		if(found == 0)
		{
			cout<<"\n\n No Search Record found......\a";
		}
	}
void student::modifyRecord()
	{
		system("cls");
		string name1,address1,sme1,dept1;
		long int contact1;
		
		int test_id,found=0;
		fstream file,file2;
		cout<<"\t\t\t\t=====================================\n\n";
		cout<<"\t\t\t\t   ********Modify Record*********** \n\n";
		cout<<"\t\t\t\t=====================================\n\n";
		file.open("student Record.txt",ios::in);
		if(!file)
		{
			cout<<"\n\n File Opening Error....!!!\a";
			getch();
			Admin_menu();
		}
		cout<<"Enter a student ID do you want to modify : ";
		cin>>test_id;
		file2.open("Modify student Record.txt",ios::out | ios::app);
		file>>name>>sid>>address>>contact>>sme>>dept;
		while(!file.eof())
		{
			if(test_id == sid)
			{
				system("cls");
				cout<<"\t\t\t\t=====================================\n\n";
				cout<<"\t\t\t\t   ****Modify Record****\n\n";
				cout<<"\t\t\t\t=====================================\n\n";
				cout<<"Enter a name : ";
				cin.ignore();
				getline(cin,name1);
			
				cout<<"Enter a Address : ";
				cin.ignore();
				getline(cin,address1);
				cout<<"\tEnter a contact Number: ";
                cin>>contact1;
				cout<<"Enter a student sme : ";
				cin.ignore();
				getline(cin,sme);
				cout<<"\tEnter a department Name : ";
				cin.ignore();
				getline(cin,dept1);				
				file2<<"  "<<name1<<"  "<<sid<<"  "<<address1<<"  "<<contact1<<"  "<<sme1<<"  "<<dept1<<endl;
                found++;
			}
			else
			{
    			file2<<"  "<<name<<"  "<<sid<<"  "<<address<<"  "<<contact<<"  "<<sme<<"  "<<dept<<endl;
			}
			file>>name>>sid>>address>>contact>>sme>>dept;
		}
		file.close();
		file2.close();
		remove("student Record.txt");
		rename("Modify student Record.txt","student Record.txt");
		
		if(found == 0)
		{
			cout<<"\n\nNo search ID found .....";
		}
		else
		cout<<"\n\n\t\t\tRecord modify successfully.....\n";
		showRecord();
    }
void student::deleteRecord()
    {
    	system("cls");
    	int test_id,found=0;
    	fstream file,file2;
    	cout<<"\t\t\t\t=====================================\n\n";
		cout<<"\t\t\t\t   ****Delete Record****\n\n";
		cout<<"\t\t\t\t=====================================\n\n";
    	file.open("student Record.txt",ios::in);
    	if(!file)
        {
        	cout<<"\n\nFile Opening Error....!!!!!!!\a";
        	getch();
        	Admin_menu();
		}
		cout<<"\n\nEnter a student ID do you want to delete  : ";
		cin>>test_id;
		file2.open("stu1.txt",ios::out | ios::app);
		file>>name>>sid>>address>>contact>>sme>>dept;
		while(!file.eof())
		{
			if(test_id == sid)
			{
				cout<<"\n\nRecord deleted successfully......";
				found++;
			}
			else
			{
				file2<<"  "<<name<<"  "<<sid<<"  "<<address<<"  "<<contact<<"  "<<sme<<"  "<<dept<<endl;
			}
			file>>name>>sid>>address>>contact>>sme>>dept;
		}
		file.close();
		file2.close();
		remove("student Record.txt");
		rename("stu1.txt","student Record.txt");
		if(found == 0)
		{
			cout<<"\n\n No search ID found.....!!!!\n";
		}
	}
	
	
int student::sid_count=10;

int main()
{
	student e;
	obj.main_menu();
    e.Admin_menu();
	return 0;
}

